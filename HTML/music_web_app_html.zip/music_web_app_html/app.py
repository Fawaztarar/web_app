import os
from flask import Flask, request, render_template, redirect
from lib.database_connection import get_flask_database_connection
from lib.album_repository import AlbumRepository
from lib.artist_repo import ArtistRepository
from lib.album import Album


# Create a new Flask app
app = Flask(__name__)

# == Your Routes Here ==

#exercise 02
#http://localhost:5001/albums

@app.route('/albums')
def get_albums():
    db_connection = get_flask_database_connection(app)
    repository = AlbumRepository(db_connection)
    albums = repository.all()
    return render_template('albums/index.html', albums=albums)




#challenge 02 and Excercise 03

@app.route("/albums/<id>")  # Ensure id is treated as an integer
def get_single_album(id):
    connection = get_flask_database_connection(app)  # Ensure proper function call
    repository = AlbumRepository(connection)  # Initialize the repository
    album = repository.find(id)  # Retrieve the album by id


    return render_template("albums/show.html", album=album)


# Exercise 04

@app.route("/albums/new")
def new_album():
    return render_template("albums/new.html")


@app.route('/albums', methods=["POST"])
def create_album():
    connection = get_flask_database_connection(app)
    repository = AlbumRepository(connection)

    title = request.form['title']  # Corrected: Closed the square bracket
    release_year = int(request.form['release_year'])  # Converted release_year to int

    # Assuming Album takes parameters in the order: id, title, release_year, artist_id
    album = Album(None, title, release_year, 1)  # 1 is a placeholder for artist_id

    repository.create(album)

    # Corrected redirect URL syntax
    return redirect(f"/albums/{album.id}")






#Challenge 03




@app.route("/artists")
def get_artists_list():
    connection = get_flask_database_connection(app)
    repository = ArtistRepository(connection)
    artists = repository.all()
    return render_template("artists/index.html", artists=artists)

@app.route("/artists/<id>")
def get_single_artist(id):
    connection = get_flask_database_connection(app)
    repository = ArtistRepository(connection)
    artist = repository.find(id)
    return render_template("artists/show.html", artist=artist)




# == Example Code Below ==

# GET /emoji
# Returns a smiley face in HTML
# Try it:
#   ; open http://localhost:5001/emoji
@app.route('/emoji', methods=['GET'])
def get_emoji():
    # We use `render_template` to send the user the file `emoji.html`
    # But first, it gets processed to look for placeholders like {{ emoji }}
    # These placeholders are replaced with the values we pass in as arguments
    return render_template('emoji.html', emoji=':)')

# This imports some more example routes for you to see how they work
# You can delete these lines if you don't need them.
from example_routes import apply_example_routes
apply_example_routes(app)

# == End Example Code ==

# These lines start the server if you run this file directly
# They also start the server configured to use the test database
# if started in test mode.
if __name__ == '__main__':
    app.run(debug=True, port=int(os.environ.get('PORT', 5001)))
