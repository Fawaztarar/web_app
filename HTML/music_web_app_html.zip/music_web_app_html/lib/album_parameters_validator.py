class AlbumParametersValidator:


    def __init__(self, title, release_year):
        self.title = title
        self.release_year = release_year

    def _is_title_valid(self):
        # Example validation: title is not None and is a non-empty string
        return self.title is not None and self.title != ""

    

    def _is_release_year_valid(self):
        # Check if release_year is not None and is a string of 4 digits
        return self.release_year is not None and self.release_year.isdigit() and len(self.release_year) == 4


    def is_valid(self):
        # Checks both title and release year
        return self._is_title_valid() and self._is_release_year_valid()















    # def __init__(self, title, release_year):
    #     self.title = title
    #     self.release_year = release_year





    # def is_valid(self):
    #     if not self._is_title_valid():
    #         return False
    #     if not self._is_release_year_valid():
    #         return False
    #     return True


    

    # def generate_errors(self):
    #         errors = []
    #         if not self._is_title_valid():
    #             errors.append("Title must not be blank")
    #         if not self._is_release_year_valid():
    #             errors.append("Release year must be a number")
    #         return errors



    
    # def is_title_valid(self):
    #     if self.title is None or self.title == "":
    #         return False
    #     return True

    # def _is_release_year_valid(self):
    #     if self.release_year is None:
    #         return False
    #     if not self.release_year.isdigit():
    #         return False
    #     return True



 

    # def get_valid_title(self):
    #     if not self._is_title_valid():
    #         raise ValueError("Cannot get valid title")
    #     return self.title
    

    # def get_valid_release_year(self):
    #     if not self._is_release_year_valid():  # Corrected function name and syntax
    #         raise ValueError("Cannot get valid release year")
    #     return int(self.release_year)  # Corrected attribute name




