from lib.album_repository import *
from lib.album import Album

"""
When all is called
All albums are returned as instances
"""

def test_all(db_connection):
    db_connection.seed('seeds/record_store.sql')
    repository = AlbumRepository(db_connection)
    result = repository.all()
    assert result == [
        Album(1, 'Doolittle', 1989, 1),
        Album(2, 'Surfer Rosa', 1988, 1)
    ]



def test_find(db_connection):
    db_connection.seed('seeds/record_store.sql')
    repository = AlbumRepository(db_connection)

    # Test finding an existing album
    result = repository.find(1)
    assert result == Album(1, 'Doolittle', 1989, 1)

    # Test finding another existing album
    result = repository.find(2)
    assert result == Album(2, 'Surfer Rosa', 1988, 1)




def test_create(db_connection):
    db_connection.seed('seeds/record_store.sql')
    repository = AlbumRepository(db_connection)

    # Test creating a new album
    album = Album(None, 'Test Title', 1000, 2)
    result = repository.create(album)
    assert album.id == 3

    # Test that the album was created
    result = repository.all()
    assert result == [
        Album(1, 'Doolittle', 1989, 1),
        Album(2, 'Surfer Rosa', 1988, 1),
        Album(3, 'Test Title', 1000, 2)
    ]


