from lib.album_parameters_validator import AlbumParametersValidator
import pytest





# Test for __init__
def test_initialization():
    validator = AlbumParametersValidator("Test Title", "1990")
    assert validator.title == "Test Title"
    assert validator.release_year == "1990"

# Tests for _is_title_valid
def test_is_title_valid_with_valid_title():
    validator = AlbumParametersValidator("Test Title", "1990")
    assert validator._is_title_valid() == True

def test_is_title_valid_with_none_title():
    validator = AlbumParametersValidator(None, "1990")
    assert validator._is_title_valid() == False

def test_is_title_valid_with_empty_title():
    validator = AlbumParametersValidator("", "1990")
    assert validator._is_title_valid() == False

# Tests for _is_release_year_valid
def test_is_release_year_valid_with_valid_year():
    validator = AlbumParametersValidator("Test Title", "1990")
    assert validator._is_release_year_valid() == True

def test_is_release_year_valid_with_non_digit_year():
    validator = AlbumParametersValidator("Test Title", "abcd")
    assert validator._is_release_year_valid() == False

def test_is_release_year_valid_with_invalid_length_year():
    validator = AlbumParametersValidator("Test Title", "19900")
    assert validator._is_release_year_valid() == False

def test_is_release_year_valid_with_none_year():
    validator = AlbumParametersValidator("Test Title", None)
    assert validator._is_release_year_valid() == False

# Test for is_valid
def test_is_valid_with_valid_data():
    validator = AlbumParametersValidator("Test Title", "1990")
    assert validator.is_valid() == True

def test_is_valid_with_invalid_title():
    validator = AlbumParametersValidator("", "1990")
    assert validator.is_valid() == False

def test_is_valid_with_invalid_year():
    validator = AlbumParametersValidator("Test Title", "abcd")
    assert validator.is_valid() == False

def test_is_valid_with_both_invalid():
    validator = AlbumParametersValidator("", "abcd")
    assert validator.is_valid() == False
























# def test_is_valid():
#     validator = AlbumParametersValidator("My Title", "1990")
#     assert validator.is_valid() == True



# def test_is_not_valid_with_bad_title():
#     validator_1 = AlbumParametersValidator("", "1990")
#     assert validator_1.is_valid() == False

#     validator_2 = AlbumParametersValidator(None, "1990")
#     assert validator_2.is_valid() == False


# def test_is_not_valid_with_bad_release_year():
#     # Test with missing release year
#     validator_1 = AlbumParametersValidator("My Title", "")
#     assert not validator_1.is_valid()

#     # Test with 'None' as release year
#     validator_2 = AlbumParametersValidator("My Title", None)
#     assert not validator_2.is_valid()

#     # Test with an invalid string as release year
#     validator_3 = AlbumParametersValidator("My Title", "fred")
#     assert not validator_3.is_valid()



# def test_generate_errors():
#     # Validator with empty title and invalid release year
#     validator_1 = AlbumParametersValidator("", "not_a_number")
#     assert validator_1.generate_errors() == [
#         "Title must not be blank",
#         "Release year must be a number"
#     ]

#     # Validator with valid title and invalid release year
#     validator_2 = AlbumParametersValidator("Title", "not_a_number")
#     assert validator_2.generate_errors() == [
#         "Release year must be a number"
#     ]

#     # Validator with empty title and valid release year
#     validator_3 = AlbumParametersValidator("", "1990")
#     assert validator_3.generate_errors() == [
#         "Title must not be blank"
#     ]




# def test_get_valid_title_if_title_valid():
#     validator_1 = AlbumParametersValidator("Title", "1990")
#     assert validator_1.get_valid_title() == "Title"




# def test_get_valid_title_refuses_if_invalid():
#     validator_1 = AlbumParametersValidator("", "1990")
#     with pytest.raises(ValueError) as err:
#         validator_1.get_valid_title()
#     assert str(err.value) == "Cannot get valid title"




# def test_get_valid_release_year_if_release_year_valid():
#     # Create an instance of AlbumParametersValidator with a valid year
#     validator_1 = AlbumParametersValidator("Title", "1990")
#     # Assert that the returned year is correct and of the right type
#     assert validator_1.get_valid_release_year() == 1990

# def test_get_valid_release_year_refuses_if_invalid():
#     # Create an instance of AlbumParametersValidator with an invalid year
#     validator_1 = AlbumParametersValidator("Title", " ")
#     # Use pytest.raises to check for ValueError
#     with pytest.raises(ValueError) as err:
#         validator_1.get_valid_release_year()
#     # Assert that the error message is correct
#     assert str(err.value) == "Cannot get valid release year"
